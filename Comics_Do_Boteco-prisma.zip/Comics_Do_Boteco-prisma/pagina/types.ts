export interface Comment {
  id: string;
  userId: string;
  username: string;
  avatar: string;
  content: string;
  date: string;
}

export interface MediaItem {
  id: string;
  title: string;
  description: string;
  coverUrl: string; // First image or thumbnail
  tags: string[];
  uploadDate: string; // ISO string
  views: number;
  likes: number;
  dislikes: number;
  comments: Comment[];
  type: 'comic' | 'video';
}

export interface Comic extends MediaItem {
  type: 'comic';
  pages: string[]; // URLs of images
}

export interface Video extends MediaItem {
  type: 'video';
  videoUrl: string;
}

export interface User {
  id: string;
  username: string;
  avatar: string; // URL
  favorites: string[]; // IDs of comics/videos
  isAdmin: boolean;
}

export type SortOption = 'date' | 'views' | 'likes' | 'dislikes';