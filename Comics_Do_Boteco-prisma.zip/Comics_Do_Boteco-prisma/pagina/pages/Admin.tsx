import React, { useState } from 'react';
import { useApp } from '../store/AppContext';
import { Comic, Video } from '../types';
import { Plus, Trash2, Edit2, Upload, Sparkles, Folder } from 'lucide-react';
import { generateComicMetadata } from '../services/geminiService';

export const Admin: React.FC = () => {
  const { items, addItem, deleteItem, currentUser } = useApp();
  const [activeTab, setActiveTab] = useState<'comics' | 'videos'>('comics');
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [loadingAI, setLoadingAI] = useState(false);

  // Form State
  const [title, setTitle] = useState('');
  const [files, setFiles] = useState<FileList | null>(null);
  const [coverIndex, setCoverIndex] = useState(0);
  const [videoUrl, setVideoUrl] = useState('');
  const [description, setDescription] = useState('');
  const [tags, setTags] = useState('');

  if (!currentUser?.isAdmin) {
    return <div className="p-10 text-center text-red-500 text-xl font-bold">Acesso Negado: Área Restrita.</div>;
  }

  const handleAI = async () => {
    if (!title) return alert("Digite um título primeiro.");
    setLoadingAI(true);
    const meta = await generateComicMetadata(title);
    setDescription(meta.description);
    setTags(meta.tags.join(', '));
    setLoadingAI(false);
  };

  const handleUpload = (e: React.FormEvent) => {
    e.preventDefault();
    if (!title) return;

    if (activeTab === 'comics') {
      if (!files || files.length === 0) return alert("Selecione imagens.");
      
      // Convert FileList to Array and sort by name to simulate folder structure ordering
      const fileArray = Array.from(files).sort((a, b) => a.name.localeCompare(b.name));
      const pageUrls = fileArray.map(f => URL.createObjectURL(f)); // Create blob URLs

      const newComic: Comic = {
        id: 'c_' + Date.now(),
        type: 'comic',
        title,
        description,
        tags: tags.split(',').map(t => t.trim()).filter(Boolean),
        coverUrl: pageUrls[coverIndex] || pageUrls[0],
        pages: pageUrls,
        uploadDate: new Date().toISOString(),
        views: 0,
        likes: 0,
        dislikes: 0,
        comments: []
      };
      addItem(newComic);
    } else {
      if (!videoUrl) return alert("URL do vídeo necessária.");
      const newVideo: Video = {
        id: 'v_' + Date.now(),
        type: 'video',
        title,
        description,
        tags: tags.split(',').map(t => t.trim()).filter(Boolean),
        coverUrl: 'https://picsum.photos/400/600?random=' + Date.now(), // Placeholder cover for video
        videoUrl,
        uploadDate: new Date().toISOString(),
        views: 0,
        likes: 0,
        dislikes: 0,
        comments: []
      };
      addItem(newVideo);
    }
    
    setIsModalOpen(false);
    resetForm();
  };

  const resetForm = () => {
    setTitle('');
    setDescription('');
    setTags('');
    setFiles(null);
    setVideoUrl('');
    setCoverIndex(0);
  };

  const filteredItems = items.filter(i => activeTab === 'comics' ? i.type === 'comic' : i.type === 'video');

  return (
    <div className="max-w-7xl mx-auto px-4 py-8">
      <div className="flex justify-between items-center mb-8">
        <h1 className="text-3xl font-bold text-boteco-red border-b-2 border-boteco-red pb-2">Painel Administrativo</h1>
        <button 
          onClick={() => setIsModalOpen(true)}
          className="bg-boteco-red hover:bg-red-700 text-white px-4 py-2 rounded-lg flex items-center space-x-2 font-bold"
        >
          <Plus size={20} /> <span>Novo Upload</span>
        </button>
      </div>

      <div className="flex space-x-4 mb-6">
        <button 
          onClick={() => setActiveTab('comics')} 
          className={`px-4 py-2 rounded ${activeTab === 'comics' ? 'bg-white text-black' : 'bg-boteco-800 text-gray-400'}`}
        >
          Comics
        </button>
        <button 
          onClick={() => setActiveTab('videos')}
          className={`px-4 py-2 rounded ${activeTab === 'videos' ? 'bg-white text-black' : 'bg-boteco-800 text-gray-400'}`}
        >
          Vídeos
        </button>
      </div>

      <div className="bg-boteco-800 rounded-lg overflow-hidden shadow-xl border border-gray-700">
        <table className="w-full text-left">
          <thead className="bg-boteco-900 text-gray-400 uppercase text-xs">
            <tr>
              <th className="px-6 py-3">Capa</th>
              <th className="px-6 py-3">Título</th>
              <th className="px-6 py-3">Data</th>
              <th className="px-6 py-3">Views</th>
              <th className="px-6 py-3 text-right">Ações</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-gray-700">
            {filteredItems.map(item => (
              <tr key={item.id} className="hover:bg-boteco-900/50">
                <td className="px-6 py-4">
                  <img src={item.coverUrl} className="h-12 w-8 object-cover rounded" />
                </td>
                <td className="px-6 py-4 font-bold">{item.title}</td>
                <td className="px-6 py-4 text-sm text-gray-400">{new Date(item.uploadDate).toLocaleDateString()}</td>
                <td className="px-6 py-4 text-sm text-gray-400">{item.views}</td>
                <td className="px-6 py-4 text-right">
                  <button onClick={() => deleteItem(item.id)} className="text-red-500 hover:text-red-300">
                    <Trash2 size={18} />
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
        {filteredItems.length === 0 && <div className="p-8 text-center text-gray-500">Nenhum item encontrado.</div>}
      </div>

      {/* Upload Modal */}
      {isModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-sm p-4">
          <div className="bg-boteco-900 rounded-xl max-w-2xl w-full border-2 border-boteco-red p-6 max-h-[90vh] overflow-y-auto">
            <h2 className="text-2xl font-bold mb-6">Upload de {activeTab === 'comics' ? 'Comic' : 'Vídeo'}</h2>
            
            <form onSubmit={handleUpload} className="space-y-4">
              <div>
                <label className="block text-sm font-bold mb-1">Título</label>
                <div className="flex gap-2">
                  <input 
                    type="text" 
                    value={title} 
                    onChange={e => setTitle(e.target.value)} 
                    className="flex-1 bg-black border border-gray-700 rounded p-2 focus:border-boteco-red outline-none" 
                    required 
                  />
                  <button type="button" onClick={handleAI} disabled={loadingAI} className="bg-indigo-600 px-3 rounded text-white hover:bg-indigo-700 flex items-center">
                    {loadingAI ? '...' : <Sparkles size={18} />}
                  </button>
                </div>
                <p className="text-xs text-gray-500 mt-1">Clique na varinha para gerar descrição com Gemini AI.</p>
              </div>

              <div>
                <label className="block text-sm font-bold mb-1">Descrição</label>
                <textarea 
                  value={description} 
                  onChange={e => setDescription(e.target.value)} 
                  className="w-full bg-black border border-gray-700 rounded p-2 focus:border-boteco-red outline-none" 
                  rows={3} 
                />
              </div>

              <div>
                <label className="block text-sm font-bold mb-1">Tags (separadas por vírgula)</label>
                <input 
                  type="text" 
                  value={tags} 
                  onChange={e => setTags(e.target.value)} 
                  className="w-full bg-black border border-gray-700 rounded p-2 focus:border-boteco-red outline-none" 
                />
              </div>

              {activeTab === 'comics' ? (
                <div>
                  <label className="block text-sm font-bold mb-1">Arquivos (Selecione a pasta ou múltiplos arquivos)</label>
                  <div className="border-2 border-dashed border-gray-600 rounded-lg p-8 text-center hover:border-boteco-red transition-colors">
                    <input 
                      type="file" 
                      multiple 
                      accept="image/*" 
                      onChange={e => setFiles(e.target.files)}
                      className="hidden" 
                      id="file-upload"
                    />
                    <label htmlFor="file-upload" className="cursor-pointer flex flex-col items-center">
                      <Folder size={40} className="text-gray-400 mb-2" />
                      <span className="text-boteco-red font-bold">Clique para selecionar arquivos</span>
                      <span className="text-xs text-gray-500 mt-1">JPEG, PNG, WEBP, AVIF</span>
                    </label>
                  </div>
                  {files && (
                    <div className="mt-2 text-sm text-green-500">
                      {files.length} arquivos selecionados.
                      <div className="mt-2">
                        <label className="text-white block mb-1">Índice da Capa (0 a {files.length - 1})</label>
                        <input type="number" min="0" max={files.length - 1} value={coverIndex} onChange={e => setCoverIndex(Number(e.target.value))} className="w-20 bg-black border border-gray-700 rounded p-1" />
                      </div>
                    </div>
                  )}
                </div>
              ) : (
                <div>
                  <label className="block text-sm font-bold mb-1">URL do Vídeo (MP4/WebM)</label>
                  <input 
                    type="url" 
                    value={videoUrl} 
                    onChange={e => setVideoUrl(e.target.value)} 
                    placeholder="https://exemplo.com/video.mp4"
                    className="w-full bg-black border border-gray-700 rounded p-2 focus:border-boteco-red outline-none" 
                    required
                  />
                </div>
              )}

              <div className="flex justify-end gap-3 pt-4 border-t border-gray-700 mt-4">
                <button type="button" onClick={() => setIsModalOpen(false)} className="px-4 py-2 text-gray-400 hover:text-white">Cancelar</button>
                <button type="submit" className="bg-boteco-red hover:bg-red-700 px-6 py-2 rounded text-white font-bold">Upload</button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};