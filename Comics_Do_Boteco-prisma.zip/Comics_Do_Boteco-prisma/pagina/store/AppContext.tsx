import React, { createContext, useContext, useState, useEffect } from 'react';
import { Comic, Video, User, SortOption, Comment } from '../types';
//import prisma from '@/lib/prisma';

interface AppState {
  items: (Comic | Video)[];
  user: User | null;
  currentUser: User | null; // Simulating session
  searchQuery: string;
  setSearchQuery: (q: string) => void;
  addItem: (item: Comic | Video) => void;
  updateItem: (item: Comic | Video) => void;
  deleteItem: (id: string) => void;
  toggleFavorite: (itemId: string) => void;
  addComment: (itemId: string, content: string) => void;
  handleReaction: (itemId: string, type: 'like' | 'dislike') => void;
  addView: (itemId: string) => void;
  login: (username: string) => void;
  logout: () => void;
}

const AppContext = createContext<AppState | undefined>(undefined);

// Mock Data Seeding
const MOCK_COMICS: Comic[] = [
  {
    id: 'c1',
    type: 'comic',
    title: 'A Lenda do Barista Noturno',
    description: 'Um barista que combate crimes servindo o café mais forte do mundo.',
    coverUrl: 'https://picsum.photos/400/600?random=1',
    pages: [
      'https://picsum.photos/800/1200?random=101',
      'https://picsum.photos/800/1200?random=102',
      'https://picsum.photos/800/1200?random=103',
      'https://picsum.photos/800/1200?random=104',
    ],
    tags: ['Ação', 'Café', 'Humor'],
    uploadDate: new Date(Date.now() - 86400000).toISOString(),
    views: 120,
    likes: 45,
    dislikes: 2,
    comments: []
  },
  {
    id: 'c2',
    type: 'comic',
    title: 'Cyberpunk São Paulo 2099',
    description: 'O futuro é neon, chuva e pastel de feira sintético.',
    coverUrl: 'https://picsum.photos/400/600?random=2',
    pages: [
      'https://picsum.photos/800/1200?random=201',
      'https://picsum.photos/800/1200?random=202'
    ],
    tags: ['Sci-Fi', 'Brasil', 'Futuro'],
    uploadDate: new Date().toISOString(),
    views: 1250,
    likes: 300,
    dislikes: 10,
    comments: []
  }
];

const MOCK_VIDEOS: Video[] = [
  {
    id: 'v1',
    type: 'video',
    title: 'Review: O Último Samurai',
    description: 'Análise detalhada do capítulo final.',
    coverUrl: 'https://picsum.photos/400/600?random=3',
    videoUrl: 'http://commondatastorage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4',
    tags: ['Review', 'Anime'],
    uploadDate: new Date(Date.now() - 100000000).toISOString(),
    views: 5000,
    likes: 800,
    dislikes: 5,
    comments: []
  }
];

export const AppProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [items, setItems] = useState<(Comic | Video)[]>([...MOCK_COMICS, ...MOCK_VIDEOS]);
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [searchQuery, setSearchQuery] = useState('');

  // Load from local storage on mount (simplified for demo)
  useEffect(() => {
    const storedUser = localStorage.getItem('boteco_user');
    if (storedUser) {
      setCurrentUser(JSON.parse(storedUser));
    }
  }, []);

  const login = (username: string) => {
    const user: User = {
      id: 'u_' + Date.now(),
      username,
      avatar: `https://api.dicebear.com/7.x/avataaars/svg?seed=${username}`,
      favorites: [],
      isAdmin: username.toLowerCase() === 'admin'
    };
    setCurrentUser(user);
    localStorage.setItem('boteco_user', JSON.stringify(user));
  };

  const logout = () => {
    setCurrentUser(null);
    localStorage.removeItem('boteco_user');
  };

  const addItem = (item: Comic | Video) => {
    setItems(prev => [item, ...prev]);
  };

  const updateItem = (updatedItem: Comic | Video) => {
    setItems(prev => prev.map(item => item.id === updatedItem.id ? updatedItem : item));
  };

  const deleteItem = (id: string) => {
    setItems(prev => prev.filter(item => item.id !== id));
  };

  const toggleFavorite = (itemId: string) => {
    if (!currentUser) return;
    const isFav = currentUser.favorites.includes(itemId);
    const newFavs = isFav 
      ? currentUser.favorites.filter(id => id !== itemId)
      : [...currentUser.favorites, itemId];
    
    const updatedUser = { ...currentUser, favorites: newFavs };
    setCurrentUser(updatedUser);
    localStorage.setItem('boteco_user', JSON.stringify(updatedUser));
  };

  const addComment = (itemId: string, content: string) => {
    if (!currentUser) return;
    const newComment: Comment = {
      id: 'cmt_' + Date.now(),
      userId: currentUser.id,
      username: currentUser.username,
      avatar: currentUser.avatar,
      content,
      date: new Date().toISOString()
    };

    setItems(prev => prev.map(item => {
      if (item.id === itemId) {
        return { ...item, comments: [newComment, ...item.comments] };
      }
      return item;
    }));
  };

  const handleReaction = (itemId: string, type: 'like' | 'dislike') => {
    setItems(prev => prev.map(item => {
      if (item.id === itemId) {
        return {
          ...item,
          likes: type === 'like' ? item.likes + 1 : item.likes,
          dislikes: type === 'dislike' ? item.dislikes + 1 : item.dislikes
        };
      }
      return item;
    }));
  };

  const addView = (itemId: string) => {
    setItems(prev => prev.map(item => {
      if (item.id === itemId) {
        return { ...item, views: item.views + 1 };
      }
      return item;
    }));
  };

  return (
    <AppContext.Provider value={{
      items,
      user: currentUser,
      currentUser,
      searchQuery,
      setSearchQuery,
      addItem,
      updateItem,
      deleteItem,
      toggleFavorite,
      addComment,
      handleReaction,
      addView,
      login,
      logout
    }}>
      {children}
    </AppContext.Provider>
  );
};

export const useApp = () => {
  const context = useContext(AppContext);
  if (!context) throw new Error('useApp must be used within AppProvider');
  return context;
};