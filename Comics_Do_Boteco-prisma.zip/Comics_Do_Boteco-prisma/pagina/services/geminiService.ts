import { GoogleGenAI } from "@google/genai";

// Helper to generate description and tags for a comic title
export const generateComicMetadata = async (title: string): Promise<{ description: string; tags: string[] }> => {
  if (!process.env.API_KEY) {
    console.warn("API Key not found. Returning mock data.");
    return {
      description: "Descrição gerada automaticamente não disponível (Sem API Key).",
      tags: ["comic", "boteco"]
    };
  }

  try {
    const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
    const model = "gemini-2.5-flash";
    
    const prompt = `
      Você é um assistente de uma loja de quadrinhos brasileira "Comics do Boteco".
      Gere uma sinopse curta (máximo 2 parágrafos) divertida e instigante para uma comic chamada "${title}".
      Também gere 5 tags relevantes separadas por vírgula.
      Responda APENAS no formato JSON:
      {
        "description": "...",
        "tags": ["tag1", "tag2", ...]
      }
    `;

    const response = await ai.models.generateContent({
      model: model,
      contents: prompt,
      config: {
        responseMimeType: "application/json"
      }
    });

    const text = response.text;
    if (!text) throw new Error("No response from AI");

    return JSON.parse(text);

  } catch (error) {
    console.error("Gemini Error:", error);
    return {
      description: "Não foi possível gerar a descrição automaticamente.",
      tags: ["erro-api", "manual"]
    };
  }
};