import React from 'react';
import { Link } from 'react-router-dom';
import { Eye, ThumbsUp, Film, Book } from 'lucide-react';
import { Comic, Video } from '../types';

interface Props {
  item: Comic | Video;
}

export const MediaCard: React.FC<Props> = ({ item }) => {
  return (
    <Link 
      to={`/${item.type}/${item.id}`} 
      className="group relative block bg-boteco-800 rounded-lg overflow-hidden border-2 border-transparent hover:border-boteco-red transition-all duration-300 transform hover:-translate-y-1 shadow-xl"
    >
      <div className="aspect-[2/3] w-full overflow-hidden relative">
        <img 
          src={item.coverUrl} 
          alt={item.title} 
          className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-black/90 via-black/20 to-transparent opacity-80 group-hover:opacity-100 transition-opacity" />
        
        {/* Type Icon Badge */}
        <div className="absolute top-2 right-2 bg-boteco-red/90 p-1.5 rounded-full text-white">
          {item.type === 'comic' ? <Book size={16} /> : <Film size={16} />}
        </div>

        {/* Stats Overlay */}
        <div className="absolute bottom-0 left-0 right-0 p-4 transform translate-y-2 group-hover:translate-y-0 transition-transform">
          <div className="flex items-center space-x-4 text-xs text-gray-300 mb-2">
             <div className="flex items-center space-x-1">
               <Eye size={14} />
               <span>{item.views}</span>
             </div>
             <div className="flex items-center space-x-1">
               <ThumbsUp size={14} />
               <span>{item.likes}</span>
             </div>
          </div>
          <h3 className="text-lg font-bold text-white leading-tight line-clamp-2 mb-1">{item.title}</h3>
          <div className="flex flex-wrap gap-1">
            {item.tags.slice(0, 3).map(tag => (
              <span key={tag} className="text-[10px] uppercase tracking-wider bg-white/10 px-2 py-0.5 rounded text-gray-200">
                {tag}
              </span>
            ))}
          </div>
        </div>
      </div>
    </Link>
  );
};