import React, { useState, useEffect, useRef } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { useApp } from '../store/AppContext';
import { ChevronLeft, ChevronRight, ThumbsUp, ThumbsDown, MessageSquare, ArrowLeft, Eye } from 'lucide-react';
import { Comic } from '../types';

export const Reader: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const { items, addView, handleReaction, addComment, currentUser } = useApp();
  const [currentPage, setCurrentPage] = useState(0);
  const [newComment, setNewComment] = useState('');
  
  // Find comic
  const comic = items.find(i => i.id === id && i.type === 'comic') as Comic | undefined;
  
  // Ref for touch handling
  const touchStart = useRef<number | null>(null);
  const touchEnd = useRef<number | null>(null);
  const isViewCounted = useRef(false);

  useEffect(() => {
    if (comic && !isViewCounted.current) {
      addView(comic.id);
      isViewCounted.current = true;
    }
  }, [comic]);

  // Keyboard Navigation
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'ArrowRight') nextPage();
      if (e.key === 'ArrowLeft') prevPage();
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [currentPage, comic]);

  if (!comic) return <div className="text-center py-20">Comic não encontrada.</div>;

  const nextPage = () => {
    if (currentPage < comic.pages.length - 1) {
      setCurrentPage(p => p + 1);
      window.scrollTo(0, 0);
    }
  };

  const prevPage = () => {
    if (currentPage > 0) {
      setCurrentPage(p => p - 1);
      window.scrollTo(0, 0);
    }
  };

  // Touch Handlers
  const onTouchStart = (e: React.TouchEvent) => {
    touchEnd.current = null;
    touchStart.current = e.targetTouches[0].clientX;
  };

  const onTouchMove = (e: React.TouchEvent) => {
    touchEnd.current = e.targetTouches[0].clientX;
  };

  const onTouchEnd = () => {
    if (!touchStart.current || !touchEnd.current) return;
    const distance = touchStart.current - touchEnd.current;
    const isLeftSwipe = distance > 50;
    const isRightSwipe = distance < -50;

    if (isLeftSwipe) nextPage();
    if (isRightSwipe) prevPage();
  };

  const postComment = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newComment.trim()) return;
    addComment(comic.id, newComment);
    setNewComment('');
  };

  return (
    <div className="min-h-screen bg-black pb-20">
      
      {/* Top Bar */}
      <div className="sticky top-16 z-40 bg-black/90 backdrop-blur border-b border-gray-800 p-4 flex items-center justify-between text-white">
        <button onClick={() => navigate(-1)} className="flex items-center hover:text-boteco-red">
          <ArrowLeft className="mr-2" /> Voltar
        </button>
        <h1 className="font-bold text-sm md:text-lg truncate max-w-[50%]">{comic.title}</h1>
        <span className="text-gray-400 text-sm">Página {currentPage + 1} / {comic.pages.length}</span>
      </div>

      {/* Reader Area */}
      <div 
        className="flex flex-col items-center justify-center min-h-[80vh] relative group cursor-pointer"
        onTouchStart={onTouchStart}
        onTouchMove={onTouchMove}
        onTouchEnd={onTouchEnd}
      >
        <img 
          src={comic.pages[currentPage]} 
          alt={`Page ${currentPage + 1}`} 
          className="max-w-full max-h-screen md:h-[90vh] object-contain shadow-2xl"
        />

        {/* Desktop Navigation Arrows (Visible on Hover) */}
        <button 
          onClick={(e) => { e.stopPropagation(); prevPage(); }}
          disabled={currentPage === 0}
          className="hidden md:flex absolute left-4 top-1/2 -translate-y-1/2 bg-black/50 hover:bg-boteco-red p-3 rounded-full text-white disabled:opacity-0 transition-all opacity-0 group-hover:opacity-100"
        >
          <ChevronLeft size={32} />
        </button>

        <button 
          onClick={(e) => { e.stopPropagation(); nextPage(); }}
          disabled={currentPage === comic.pages.length - 1}
          className="hidden md:flex absolute right-4 top-1/2 -translate-y-1/2 bg-black/50 hover:bg-boteco-red p-3 rounded-full text-white disabled:opacity-0 transition-all opacity-0 group-hover:opacity-100"
        >
          <ChevronRight size={32} />
        </button>
      </div>

      {/* Mobile Nav Bottom */}
      <div className="md:hidden flex justify-between px-4 py-4 bg-gray-900">
         <button onClick={prevPage} disabled={currentPage === 0} className="bg-gray-800 px-6 py-2 rounded text-white disabled:opacity-50">Anterior</button>
         <button onClick={nextPage} disabled={currentPage === comic.pages.length -1} className="bg-boteco-red px-6 py-2 rounded text-white disabled:opacity-50">Próxima</button>
      </div>

      {/* Engagement Section */}
      <div className="max-w-4xl mx-auto px-4 mt-12 bg-boteco-800 rounded-lg p-6 border-t-2 border-boteco-red">
        <div className="flex items-center justify-between mb-8 border-b border-gray-700 pb-4">
          <div className="flex space-x-6">
            <button onClick={() => handleReaction(comic.id, 'like')} className="flex items-center space-x-2 text-gray-300 hover:text-green-500 transition-colors">
              <ThumbsUp /> <span>{comic.likes}</span>
            </button>
            <button onClick={() => handleReaction(comic.id, 'dislike')} className="flex items-center space-x-2 text-gray-300 hover:text-red-500 transition-colors">
              <ThumbsDown /> <span>{comic.dislikes}</span>
            </button>
            <div className="flex items-center space-x-2 text-gray-400">
              <Eye /> <span>{comic.views} visualizações</span>
            </div>
          </div>
        </div>

        {/* Comments */}
        <div>
          <h3 className="text-xl font-bold mb-4 flex items-center"><MessageSquare className="mr-2"/> Comentários</h3>
          
          {currentUser ? (
            <form onSubmit={postComment} className="mb-8 flex gap-4">
              <img src={currentUser.avatar} className="w-10 h-10 rounded-full" />
              <div className="flex-1">
                <textarea 
                  value={newComment}
                  onChange={e => setNewComment(e.target.value)}
                  className="w-full bg-boteco-900 border border-gray-700 rounded-lg p-3 text-white focus:border-boteco-red focus:outline-none"
                  placeholder="Deixe seu comentário..."
                  rows={2}
                />
                <button type="submit" className="mt-2 bg-boteco-red px-4 py-1.5 rounded text-white text-sm font-bold">Enviar</button>
              </div>
            </form>
          ) : (
            <div className="bg-boteco-900/50 p-4 rounded text-center mb-6">Faça login para comentar.</div>
          )}

          <div className="space-y-6">
            {comic.comments.length === 0 && <p className="text-gray-500 italic">Seja o primeiro a comentar!</p>}
            {comic.comments.map(comment => (
              <div key={comment.id} className="flex gap-4">
                <img src={comment.avatar} alt={comment.username} className="w-10 h-10 rounded-full border border-gray-700" />
                <div>
                  <div className="flex items-center space-x-2">
                    <span className="font-bold text-white">{comment.username}</span>
                    <span className="text-xs text-gray-500">{new Date(comment.date).toLocaleDateString()}</span>
                  </div>
                  <p className="text-gray-300 mt-1">{comment.content}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

    </div>
  );
};