import React, { useState } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { Search, User as UserIcon, LogOut, Menu, X, BookOpen } from 'lucide-react';
import { useApp } from '../store/AppContext';

export const Navbar: React.FC = () => {
  const { currentUser, searchQuery, setSearchQuery, logout } = useApp();
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const location = useLocation();

  const isActive = (path: string) => location.pathname === path ? 'text-boteco-red font-bold' : 'text-gray-300 hover:text-white';

  return (
    <nav className="sticky top-0 z-50 bg-boteco-900 border-b-2 border-boteco-red shadow-lg">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          
          {/* Logo */}
          <Link to="/" className="flex items-center space-x-2">
            <BookOpen className="h-8 w-8 text-boteco-red" />
            <span className="text-xl font-bold tracking-wider text-white">
              COMICS <span className="text-boteco-red">DO BOTECO</span>
            </span>
          </Link>

          {/* Desktop Nav */}
          <div className="hidden md:flex items-center space-x-8">
            <Link to="/" className={isActive('/')}>Home</Link>
            <Link to="/videos" className={isActive('/videos')}>Vídeos</Link>
            {currentUser && <Link to="/favorites" className={isActive('/favorites')}>Favoritos</Link>}
            {currentUser?.isAdmin && <Link to="/admin" className={isActive('/admin')}>Admin</Link>}
          </div>

          {/* Search Bar (Desktop) */}
          <div className="hidden md:block flex-1 max-w-xs mx-4">
            <div className="relative">
              <input
                type="text"
                placeholder="Pesquisar comics ou vídeos..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full bg-boteco-800 text-white rounded-full px-4 py-1.5 pl-10 focus:outline-none focus:ring-2 focus:ring-boteco-red border border-gray-700"
              />
              <Search className="absolute left-3 top-2 h-4 w-4 text-gray-400" />
            </div>
          </div>

          {/* User Section */}
          <div className="hidden md:flex items-center space-x-4">
            {currentUser ? (
              <div className="flex items-center space-x-3">
                <img src={currentUser.avatar} alt="Avatar" className="h-8 w-8 rounded-full border border-boteco-red" />
                <span className="text-sm font-medium">{currentUser.username}</span>
                <button onClick={logout} className="text-gray-400 hover:text-white">
                  <LogOut className="h-5 w-5" />
                </button>
              </div>
            ) : (
              <Link to="/login" className="bg-boteco-red hover:bg-red-700 text-white px-4 py-2 rounded-md text-sm font-medium transition-colors">
                Entrar
              </Link>
            )}
          </div>

          {/* Mobile Menu Button */}
          <div className="md:hidden">
            <button onClick={() => setIsMenuOpen(!isMenuOpen)} className="text-white p-2">
              {isMenuOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Menu */}
      {isMenuOpen && (
        <div className="md:hidden bg-boteco-900 border-b border-gray-800 px-2 pt-2 pb-3 space-y-1">
          <Link to="/" className="block px-3 py-2 rounded-md text-base font-medium text-white hover:bg-boteco-800">Home</Link>
          <Link to="/videos" className="block px-3 py-2 rounded-md text-base font-medium text-white hover:bg-boteco-800">Vídeos</Link>
          {currentUser && <Link to="/favorites" className="block px-3 py-2 rounded-md text-base font-medium text-white hover:bg-boteco-800">Favoritos</Link>}
          {currentUser?.isAdmin && <Link to="/admin" className="block px-3 py-2 rounded-md text-base font-medium text-white hover:bg-boteco-800">Admin</Link>}
          
          <div className="px-3 py-2">
            <input
              type="text"
              placeholder="Pesquisar..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full bg-boteco-800 text-white rounded-md px-3 py-2 border border-gray-700"
            />
          </div>

          {currentUser ? (
             <div className="flex items-center justify-between px-3 py-2 border-t border-gray-700 mt-2">
               <div className="flex items-center space-x-2">
                 <img src={currentUser.avatar} className="h-8 w-8 rounded-full" />
                 <span>{currentUser.username}</span>
               </div>
               <button onClick={logout} className="text-red-500">Sair</button>
             </div>
          ) : (
            <Link to="/login" className="block w-full text-center mt-4 bg-boteco-red text-white py-2 rounded-md">Entrar</Link>
          )}
        </div>
      )}
    </nav>
  );
};