import React from 'react';
import { HashRouter, Routes, Route, Navigate, useParams } from 'react-router-dom';
import { AppProvider, useApp } from './store/AppContext';
import { Navbar } from './components/Navbar';
import { Home } from './pages/Home';
import { Reader } from './pages/Reader';
import { Admin } from './pages/Admin';
import { Login } from './pages/Login';
import { MediaCard } from './components/MediaCard';
import { Video } from './types';

// Placeholder for Video Player
const VideoPlayer: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const { items } = useApp();
  const video = items.find((i) => i.id === id && i.type === 'video') as Video | undefined;

  if (!video) return <div className="text-center p-10">Vídeo não encontrado</div>;

  return (
    <div className="max-w-6xl mx-auto p-4">
      <div className="aspect-video bg-black rounded-lg overflow-hidden border-2 border-boteco-red mb-4">
        <video controls className="w-full h-full" src={video.videoUrl} poster={video.coverUrl}>
          Seu navegador não suporta vídeos.
        </video>
      </div>
      <h1 className="text-2xl font-bold">{video.title}</h1>
      <p className="text-gray-400 mt-2">{video.description}</p>
    </div>
  );
};

const Favorites: React.FC = () => {
   const { items, currentUser } = useApp();
   
   if (!currentUser) return <Navigate to="/login" />;
   
   const favItems = items.filter((i) => currentUser.favorites.includes(i.id));

   return (
     <div className="max-w-7xl mx-auto p-4 py-8">
       <h1 className="text-2xl font-bold mb-6 text-boteco-red">Meus Favoritos</h1>
       {favItems.length > 0 ? (
         <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-6">
           {favItems.map((item) => <MediaCard key={item.id} item={item} />)}
         </div>
       ) : (
         <p className="text-gray-500">Você ainda não tem favoritos.</p>
       )}
     </div>
   );
};

// Simplified Videos List Page
const VideosList: React.FC = () => {
  const { items } = useApp();
  const videos = items.filter((i) => i.type === 'video');

  return (
    <div className="max-w-7xl mx-auto p-4 py-8">
      <h1 className="text-2xl font-bold mb-6 text-boteco-red">Vídeos</h1>
      <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-6">
        {videos.map((item) => <MediaCard key={item.id} item={item} />)}
      </div>
    </div>
  );
};

const App: React.FC = () => {
  return (
    <AppProvider>
      <HashRouter>
        <div className="min-h-screen bg-boteco-900 text-gray-100 font-sans selection:bg-boteco-red selection:text-white">
          <Navbar />
          <Routes>
            <Route path="/" element={<Home />} />
            <Route path="/login" element={<Login />} />
            <Route path="/comic/:id" element={<Reader />} />
            <Route path="/video/:id" element={<VideoPlayer />} />
            <Route path="/videos" element={<VideosList />} />
            <Route path="/favorites" element={<Favorites />} />
            <Route path="/admin" element={<Admin />} />
          </Routes>
        </div>
      </HashRouter>
    </AppProvider>
  );
};

export default App;