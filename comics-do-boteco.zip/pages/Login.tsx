import React, { useState } from 'react';
import { useApp } from '../store/AppContext';
import { useNavigate } from 'react-router-dom';
import { BookOpen } from 'lucide-react';

export const Login: React.FC = () => {
  const [username, setUsername] = useState('');
  const { login } = useApp();
  const navigate = useNavigate();

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    if (username.trim()) {
      login(username);
      navigate('/');
    }
  };

  return (
    <div className="min-h-[80vh] flex items-center justify-center px-4">
      <div className="bg-boteco-800 p-8 rounded-xl shadow-2xl border-2 border-boteco-red w-full max-w-md">
        <div className="flex justify-center mb-6">
          <BookOpen className="h-12 w-12 text-boteco-red" />
        </div>
        <h2 className="text-2xl font-bold text-center text-white mb-6">Entrar no Boteco</h2>
        <form onSubmit={handleLogin} className="space-y-6">
          <div>
            <label className="block text-sm font-medium text-gray-400 mb-2">Username</label>
            <input
              type="text"
              value={username}
              onChange={(e) => setUsername(e.target.value)}
              className="w-full px-4 py-3 bg-boteco-900 border border-gray-700 rounded-lg focus:ring-2 focus:ring-boteco-red focus:outline-none text-white"
              placeholder="Digite seu nome (use 'admin' para acesso total)"
            />
          </div>
          <button
            type="submit"
            className="w-full bg-boteco-red hover:bg-red-700 text-white font-bold py-3 rounded-lg transition-colors"
          >
            Entrar
          </button>
        </form>
        <p className="mt-4 text-center text-sm text-gray-500">
          Dica: Use <strong>admin</strong> para acessar o painel de upload.
        </p>
      </div>
    </div>
  );
};