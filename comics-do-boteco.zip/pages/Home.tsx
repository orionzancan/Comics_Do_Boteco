import React, { useMemo } from 'react';
import { useApp } from '../store/AppContext';
import { MediaCard } from '../components/MediaCard';
import { Shuffle, Flame, Clock } from 'lucide-react';
import { useNavigate } from 'react-router-dom';

export const Home: React.FC = () => {
  const { items, searchQuery } = useApp();
  const navigate = useNavigate();

  const filteredItems = useMemo(() => {
    if (!searchQuery) return items;
    return items.filter(i => 
      i.title.toLowerCase().includes(searchQuery.toLowerCase()) || 
      i.tags.some(t => t.toLowerCase().includes(searchQuery.toLowerCase()))
    );
  }, [items, searchQuery]);

  // Section Data
  const hotItems = useMemo(() => [...filteredItems].sort((a, b) => b.views - a.views).slice(0, 4), [filteredItems]);
  const recentItems = useMemo(() => [...filteredItems].sort((a, b) => new Date(b.uploadDate).getTime() - new Date(a.uploadDate).getTime()).slice(0, 8), [filteredItems]);

  const handleRandom = () => {
    const comics = items.filter(i => i.type === 'comic');
    if (comics.length > 0) {
      const random = comics[Math.floor(Math.random() * comics.length)];
      navigate(`/comic/${random.id}`);
    }
  };

  if (searchQuery) {
    return (
      <div className="max-w-7xl mx-auto px-4 py-8">
        <h2 className="text-2xl font-bold mb-6 border-l-4 border-boteco-red pl-3">Resultados da Pesquisa</h2>
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-6">
          {filteredItems.map(item => <MediaCard key={item.id} item={item} />)}
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-7xl mx-auto px-4 py-8 space-y-12">
      
      {/* Hero / Action Bar */}
      <div className="flex flex-col md:flex-row justify-between items-center bg-gradient-to-r from-boteco-800 to-boteco-900 p-6 rounded-2xl border border-gray-800 shadow-2xl relative overflow-hidden">
        <div className="relative z-10">
          <h1 className="text-3xl font-bold mb-2">Bem-vindo ao Boteco</h1>
          <p className="text-gray-400">Puxe uma cadeira, peça uma bebida e leia as melhores histórias.</p>
        </div>
        <button 
          onClick={handleRandom}
          className="mt-4 md:mt-0 relative z-10 flex items-center space-x-2 bg-boteco-red hover:bg-red-700 text-white px-6 py-3 rounded-full font-bold transition-all transform hover:scale-105 shadow-lg shadow-red-900/50"
        >
          <Shuffle size={20} />
          <span>Ler Comic Aleatória</span>
        </button>
        {/* Background Accent */}
        <div className="absolute -right-10 -top-10 w-40 h-40 bg-boteco-red/20 rounded-full blur-3xl"></div>
      </div>

      {/* Hot Comics */}
      <section>
        <div className="flex items-center space-x-2 mb-6">
          <Flame className="text-boteco-red" />
          <h2 className="text-2xl font-bold">Hot Comics</h2>
        </div>
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-4 gap-6">
          {hotItems.map(item => <MediaCard key={item.id} item={item} />)}
        </div>
      </section>

      {/* Today / Recent */}
      <section>
        <div className="flex items-center space-x-2 mb-6">
          <Clock className="text-boteco-red" />
          <h2 className="text-2xl font-bold">Adicionados Recentemente</h2>
        </div>
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-6">
          {recentItems.map(item => <MediaCard key={item.id} item={item} />)}
        </div>
      </section>

    </div>
  );
};